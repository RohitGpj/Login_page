<?php
$conn = mysqli_connect("localhost", "root","", "Login_form"); // Establishing Connection with Server
  
if(isset($_POST['submit'])){
    if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['contact']) && !empty($_POST['address'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
      $query= "insert into record(name,email,contact,address) values ('$name', '$email', '$contact', '$address')";
    $run= mysqli_query($conn,$query) or die(mysqli_error());
if ($run){
    echo"form is submitted successfully";
}
}
else{echo"Some Fields are Blank....!!";
}
}

?>
